# Wave 1 — Materiais e canais: SPEC READY e matriz implementação × spec (05/10/2026)

Wave 1 do [pacote de modelagem e superfície](surface-modeling-waves-2026-10-05.md).
Decisão D1 (05/10/2026, responsável do produto): **cada camada tem canal-alvo**.
A camada raster e a de efeito pertencem a um canal; tipos de camada que produzem
vários canais (receitas na W4, decalque por canal na W5) declaram suas saídas no
próprio tipo.

## SPEC READY

| Campo | Definição |
| --- | --- |
| Objetivo | ligar ponta a ponta os seis canais que o `Material` já guarda (albedo, normal, rugosidade, metálico, emissão, altura): pintura, composição, renderer (wgpu e software) e exportação |
| Não objetivos | displacement geométrico (P3D-054 veta remesh silencioso); backend GL legado (AGENTS §0.1: sem feature nova no egui); pintura direta de normal map (o normal é importado ou derivado da altura); nós e receitas (W4) |
| Modelo de dados | `PaintLayer.channel: TextureChannel` (padrão Albedo, campo opcional na serialização); cada canal tem sua camada base; `Material.<canal>_texture` é o cache composto do canal (como o albedo já é); `ToolSettings.paint_channel_value` para os canais escalares |
| Composição | por canal: só as camadas daquele canal; parcial por tiles como hoje |
| Renderer | wgpu: uniform de material + mapas por asset (escalares e normal em formato linear, albedo e emissão em sRGB); normal map e bump de altura por derivadas de tela (sem tangentes nos vértices); software: iluminação por pixel quando há mapas |
| Eventos | `TextureUpdate.channel`: upload parcial só do canal pintado |
| Exportação | glTF: `metallicRoughnessTexture` empacotado (G = rugosidade, B = metálico), `normalTexture` (importado ou derivado da altura), `emissiveTexture`; OBJ: mapas no `.mtl` |
| Undo | trocar de canal não entra no histórico; pintar continua um passo por traço |
| Persistência | campos novos com `serde(default)`; projetos antigos abrem com tudo em Albedo |
| Invalidação | revisão de textura por canal no renderer |

## Matriz

| Requisito | Origem | Antes (05/10) | Estado após a wave |
| --- | --- | --- | --- |
| Modelo único de material compartilhado por viewport, Paint e export | P3D-050 | `Material` com 6 canais, só albedo usado | _preencher_ |
| Albedo: cor, textura, resultado do Paint | P3D-051 | COMPLIANT | _preencher_ |
| Normal / bump | P3D-052 | MISSING no renderer e no export | _preencher_ |
| Rugosidade (representação canônica única) | P3D-053 | escalar sem efeito visual; mapa ignorado | _preencher_ |
| Altura sem remesh | P3D-054 | MISSING | _preencher_ |
| Pintar canais com o mesmo sistema de camadas | P3D-062 | `paint_channel` sem uso | _preencher_ |
| Export dos mapas corretos | P3D-062, P3D-068 | só albedo | _preencher_ |
| Perfis Toon e Glass; fallback claro | P3D-140 | Unlit e Emissive parciais | _preencher_ |
| Presets de material | const. 08 | MISSING | _preencher_ |
| Dithering e perfis retrô | const. 08 | MISSING | _preencher_ |
| Presets de pivô e dobradiça | cap. 43 | MISSING | _preencher_ |
| Dimensões, escala de jogo, validação de bounds | const. 08, cap. 43 | parcial | _preencher_ |
| Textos do HUD por `TextId`; redesenho coalescido; gramática única | AGENTS §3, ADR 007 | parcial | _preencher_ |
| Inset métrico, plano por 3 pontos, imprint multi-face, Knife entre faces | matrizes DRAW/POLY | parcial | _preencher_ |
