//! Sombreamento de material compartilhado (Wave 1, P3D-050–054, P3D-140).
//!
//! O backend de software usa estas funções; o shader do wgpu
//! (`shade_material` em `render-wgpu`) espelha as mesmas fórmulas. Mudou aqui,
//! muda lá.
//!
//! Modelo: difuso Lambert reduzido pelo metálico, especular Blinn-Phong com
//! expoente pela rugosidade e cor pelo metálico (0,04 em dielétricos), emissão
//! somada. Toon quantiza a luz em três bandas; Glass soma Fresnel e devolve
//! opacidade parcial; Unlit e Emissive não recebem luz.

use glam::Vec3;
pub use petunia_project::ShaderProfile;

/// Dados do material num ponto da superfície.
#[derive(Clone, Copy, Debug)]
pub struct MaterialInputs {
    pub albedo: Vec3,
    /// Normal já perturbada por normal map ou altura; zero = sem luz.
    pub normal: Vec3,
    pub roughness: f32,
    pub metallic: f32,
    pub emission: Vec3,
    pub profile: ShaderProfile,
    /// Opacidade base do vidro.
    pub glass_alpha: f32,
}

/// Luz da vista.
#[derive(Clone, Copy, Debug)]
pub struct Lighting {
    pub light: Vec3,
    /// Direção da superfície para o observador.
    pub view: Vec3,
    pub ambient: f32,
    pub diffuse: f32,
    pub ao: f32,
    pub light_color: Vec3,
}

/// Cor (linear, 0–1) e opacidade de um ponto.
pub fn shade(input: &MaterialInputs, lighting: &Lighting) -> (Vec3, f32) {
    let ao = lighting.ao;
    if matches!(
        input.profile,
        ShaderProfile::Unlit | ShaderProfile::Emissive
    ) || input.normal.length() < 0.1
    {
        return (input.albedo * ao + input.emission, 1.0);
    }
    let n = input.normal.normalize();
    let l = lighting.light.normalize_or_zero();
    let v = lighting.view.normalize_or_zero();
    let rough = input.roughness.clamp(0.0, 1.0);
    let metal = input.metallic.clamp(0.0, 1.0);
    let mut diff = n.dot(l).max(0.0);
    let h = (l + v).normalize_or_zero();
    let power = 2.0f32.powf(10.0 * (1.0 - rough)) + 2.0;
    let mut spec = n.dot(h).max(0.0).powf(power) * (1.0 - 0.85 * rough);
    if input.profile == ShaderProfile::Toon {
        diff = if diff > 0.6 {
            1.0
        } else if diff > 0.15 {
            0.6
        } else {
            0.25
        };
        spec = if spec >= 0.5 { 1.0 } else { 0.0 };
    }
    let diffuse = input.albedo * (1.0 - metal);
    let spec_color = Vec3::splat(0.04).lerp(input.albedo, metal);
    let lit = lighting.ambient * ao + lighting.diffuse * diff * (1.0 + (ao - 1.0) * 0.5);
    let mut color = diffuse * lit * lighting.light_color
        + spec_color * spec * lighting.diffuse * 1.6
        + input.emission;
    let mut alpha = 1.0;
    if input.profile == ShaderProfile::Glass {
        let fresnel = (1.0 - n.dot(v).abs().clamp(0.0, 1.0)).powi(4);
        color += Vec3::splat(0.6 * fresnel);
        alpha = (input.glass_alpha + 0.5 * fresnel).clamp(0.1, 0.95);
    }
    (color, alpha)
}

/// Limiar do dithering ordenado Bayer 4×4 em `(x, y)` (0–1).
pub fn bayer4(x: u32, y: u32) -> f32 {
    const BAYER: [f32; 16] = [
        0.0, 8.0, 2.0, 10.0, 12.0, 4.0, 14.0, 6.0, 3.0, 11.0, 1.0, 9.0, 15.0, 7.0, 13.0, 5.0,
    ];
    (BAYER[((y % 4) * 4 + x % 4) as usize] + 0.5) / 16.0
}

/// Prévia retrô (const. 08): quantiza em `levels` níveis por canal com
/// dithering ordenado. `levels < 2` devolve a cor como está.
pub fn retro(color: [f32; 3], x: u32, y: u32, levels: u32) -> [f32; 3] {
    if levels < 2 {
        return color;
    }
    let steps = (levels - 1) as f32;
    let threshold = bayer4(x, y);
    color.map(|c| ((c.clamp(0.0, 1.0) * steps + threshold).floor() / steps).clamp(0.0, 1.0))
}

/// Base tangente de um triângulo: `(dP/du, dP/dv)` com V da malha para cima
/// (no wgpu a UV chega no espaço da textura, com V para baixo, e o shader
/// troca o sinal do bitangente — o resultado é o mesmo).
pub fn triangle_tangents(positions: [Vec3; 3], uvs: [[f32; 2]; 3]) -> Option<(Vec3, Vec3)> {
    let e1 = positions[1] - positions[0];
    let e2 = positions[2] - positions[0];
    let (du1, dv1) = (uvs[1][0] - uvs[0][0], uvs[1][1] - uvs[0][1]);
    let (du2, dv2) = (uvs[2][0] - uvs[0][0], uvs[2][1] - uvs[0][1]);
    let det = du1 * dv2 - du2 * dv1;
    if det.abs() < 1.0e-12 || !det.is_finite() {
        return None;
    }
    let r = det.recip();
    let tangent = (e1 * dv2 - e2 * dv1) * r;
    let bitangent = (e2 * du1 - e1 * du2) * r;
    (tangent.is_finite() && bitangent.is_finite()).then_some((tangent, bitangent))
}

/// Normal perturbada por um texel de normal map (espaço tangente, +Y = +V).
pub fn apply_normal_map(
    n: Vec3,
    tangent: Vec3,
    bitangent: Vec3,
    texel: [u8; 4],
    scale: f32,
) -> Vec3 {
    let decode = |c: u8| c as f32 / 255.0 * 2.0 - 1.0;
    let (x, y, z) = (
        decode(texel[0]) * scale,
        decode(texel[1]) * scale,
        decode(texel[2]),
    );
    let t = (tangent - n * n.dot(tangent)).normalize_or_zero();
    let b = (bitangent - n * n.dot(bitangent) - t * t.dot(bitangent)).normalize_or_zero();
    (t * x + b * y + n * z).normalize_or(n)
}

/// Normal inclinada pelo gradiente da altura (`dh/du`, `dh/dv`, V para cima).
pub fn apply_height_gradient(
    n: Vec3,
    tangent: Vec3,
    bitangent: Vec3,
    dh_du: f32,
    dh_dv: f32,
    scale: f32,
) -> Vec3 {
    let along = |axis: Vec3, dh: f32| {
        let len = axis.length();
        if len > 1.0e-9 {
            axis / len * (dh / len)
        } else {
            Vec3::ZERO
        }
    };
    let gradient = along(tangent, dh_du) + along(bitangent, dh_dv);
    let gradient = gradient - n * n.dot(gradient);
    (n - gradient * scale).normalize_or(n)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn lighting() -> Lighting {
        Lighting {
            light: Vec3::Z,
            view: Vec3::Z,
            ambient: 0.4,
            diffuse: 0.6,
            ao: 1.0,
            light_color: Vec3::ONE,
        }
    }

    fn input(roughness: f32, metallic: f32, profile: ShaderProfile) -> MaterialInputs {
        MaterialInputs {
            albedo: Vec3::new(0.8, 0.2, 0.2),
            normal: Vec3::Z,
            roughness,
            metallic,
            emission: Vec3::ZERO,
            profile,
            glass_alpha: 0.35,
        }
    }

    #[test]
    fn smooth_surfaces_shine_more_and_metal_tints_the_highlight() {
        let (rough, _) = shade(&input(1.0, 0.0, ShaderProfile::Pbr), &lighting());
        let (smooth, _) = shade(&input(0.1, 0.0, ShaderProfile::Pbr), &lighting());
        assert!(smooth.length() > rough.length(), "brilho maior no liso");
        let (metal, _) = shade(&input(0.1, 1.0, ShaderProfile::Pbr), &lighting());
        // Metal: sem difuso, reflexo na cor do albedo (vermelho domina).
        assert!(metal.x > metal.y * 2.0);
    }

    #[test]
    fn toon_quantizes_light_and_unlit_ignores_it() {
        let mut lit = lighting();
        lit.light = Vec3::new(0.0, 0.7, 0.71);
        let (a, _) = shade(&input(0.9, 0.0, ShaderProfile::Toon), &lit);
        lit.light = Vec3::new(0.0, 0.6, 0.8);
        let (b, _) = shade(&input(0.9, 0.0, ShaderProfile::Toon), &lit);
        assert!((a - b).length() < 1e-5, "mesma banda");
        let (unlit, alpha) = shade(&input(0.5, 0.0, ShaderProfile::Unlit), &lit);
        assert_eq!(unlit, Vec3::new(0.8, 0.2, 0.2));
        assert_eq!(alpha, 1.0);
    }

    #[test]
    fn glass_is_translucent_and_more_opaque_at_grazing_angles() {
        let (_, facing) = shade(&input(0.05, 0.0, ShaderProfile::Glass), &lighting());
        let mut grazing = input(0.05, 0.0, ShaderProfile::Glass);
        grazing.normal = Vec3::new(0.0, 0.98, 0.2).normalize();
        let (_, edge) = shade(&grazing, &lighting());
        assert!(facing < 0.5 && edge > facing);
    }

    #[test]
    fn retro_dither_quantizes_to_the_requested_levels() {
        assert_eq!(retro([0.3, 0.6, 0.9], 1, 2, 0), [0.3, 0.6, 0.9]);
        let out = retro([0.5, 0.5, 0.5], 3, 1, 4);
        for c in out {
            let step = c * 3.0;
            assert!((step - step.round()).abs() < 1e-5, "{c} fora dos 4 níveis");
        }
        // Mesmo valor, pixels diferentes: o padrão espalha o erro.
        let a = retro([0.5; 3], 0, 0, 2);
        let b = retro([0.5; 3], 1, 0, 2);
        assert_ne!(a, b);
    }

    #[test]
    fn flat_normal_texel_keeps_the_normal_and_height_slopes_tilt_it() {
        let (t, b) = triangle_tangents(
            [Vec3::ZERO, Vec3::X, Vec3::Y],
            [[0.0, 0.0], [1.0, 0.0], [0.0, 1.0]],
        )
        .unwrap();
        assert!((t - Vec3::X).length() < 1e-6 && (b - Vec3::Y).length() < 1e-6);
        let flat = apply_normal_map(Vec3::Z, t, b, [128, 128, 255, 255], 1.0);
        assert!((flat - Vec3::Z).length() < 0.02);
        // +Y do mapa inclina a normal para +V.
        let up = apply_normal_map(Vec3::Z, t, b, [128, 230, 200, 255], 1.0);
        assert!(up.y > 0.2);
        // Altura subindo em +U inclina a normal para -U.
        let tilted = apply_height_gradient(Vec3::Z, t, b, 1.0, 0.0, 0.5);
        assert!(tilted.x < -0.1);
    }
}
