# Parts planares antes da extrusão — reconciliação

Escopo: perfis persistentes do DRAW (`ProfileResource` + `SplineResource`) no shell Slint. Referências canônicas: [workflow shape-first](../bible/foundations/02-workflow-modelagem-shape-first.md), [seleção unificada](../bible/specs/p3d-015-object-mode-modelo-unificado-de-selecao.md) e [UI Baseline](../bible/foundations/36-ui-baseline-temas-plugin-panels.md).

| Requisito | Antes | Depois | Evidência |
|---|---|---|---|
| Forma plana persistente sem volume | COMPLIANT | COMPLIANT | `CreateProfileCmd`, `ProfileResource` |
| Visibilidade no DRAW e edição de nós | COMPLIANT | COMPLIANT | `draw_shapes.rs`, testes de perfil existentes |
| Lista Parts com seleção e estado | MISSING | COMPLIANT | `SlintUiBridge::view_model`, seleção por UUID, visibilidade/bloqueio |
| Seleção pelo viewport no domínio Object | MISSING | COMPLIANT | hit test de interior/contorno em pixels, `profile_part_at` |
| Mover, girar e redimensionar sem volume | MISSING | COMPLIANT | transformação do plano e spline, `TransformProfileCmd`, um Undo |
| Operações de objeto | MISSING | PARTIALLY_COMPLIANT | renomear, duplicar e excluir; seleção múltipla de perfis ainda não implementada |

O perfil continua sendo o dado autoral. Transformações da Part plana alteram esse perfil e sua spline, então Extrude/Revolve posteriores usam a forma editada. A prévia de arrasto é transacional; o commit passa por um comando atômico. A representação do projeto recebeu apenas campos anexados ao fim do esquema para visibilidade e bloqueio, preservando o layout postcard anterior. O site público congelado não foi alterado.

## Verificação

- `cargo +1.98.1 fmt --all -- --check`
- `cargo +1.98.1 check -p petunia_ui_slint`
- `cargo +1.98.1 test -p petunia_ui_slint --lib`
- `cargo +1.98.1 clippy -p petunia_ui_slint --all-targets -- -D warnings`
- `cargo +1.98.1 run -p xtask -- docs-check`
- `cargo +1.98.1 run -p xtask -- bible-check`
- `cargo +1.98.1 run -p xtask -- ui-guard --strict`

Os resultados são registrados no checkpoint de entrega; esta lista descreve os gates, não declara sua aprovação antecipada.
