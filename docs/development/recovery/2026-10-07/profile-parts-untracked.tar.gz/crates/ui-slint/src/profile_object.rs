//! Profile Parts: selection and transactional object transforms for planar shapes.

use glam::{DQuat, DVec3, EulerRot, Vec2, Vec3};
use petunia_project::{ProfileResource, ProjectChanges, SplineResource};

use crate::{PetuniaViewport, SlintUiBridge, TransformKind};

pub(crate) struct ProfileObjectTransform {
    pub id: uuid::Uuid,
    pub kind: TransformKind,
    profile: ProfileResource,
    spline: SplineResource,
    pub components: Vec3,
}

impl ProfileObjectTransform {
    fn new<V: PetuniaViewport>(bridge: &SlintUiBridge<V>, kind: TransformKind) -> Option<Self> {
        let id = bridge.selected_profile_id?;
        let project = &bridge.state.project.project;
        let profile = project.get_profile(id)?.clone();
        let spline = project.get_spline(profile.spline_id)?.clone();
        Some(Self {
            id,
            kind,
            profile,
            spline,
            components: if kind == TransformKind::Scale {
                Vec3::ONE
            } else {
                Vec3::ZERO
            },
        })
    }

    fn geometry(&self, components: Vec3) -> Option<(ProfileResource, SplineResource)> {
        if !components.is_finite() {
            return None;
        }
        let mut profile = self.profile.clone();
        let mut spline = self.spline.clone();
        let wp = self.profile.workplane;
        let origin = DVec3::from_array(wp.origin);
        let right = DVec3::from_array(wp.right);
        let up = DVec3::from_array(wp.up);
        let center = if self.spline.points.is_empty() {
            origin
        } else {
            self.spline
                .points
                .iter()
                .map(|p| origin + right * p.position[0] + up * p.position[1])
                .sum::<DVec3>()
                / self.spline.points.len() as f64
        };
        let offset = DVec3::new(
            components.x as f64,
            components.y as f64,
            components.z as f64,
        );
        let transform = |v: DVec3| match self.kind {
            TransformKind::Position => v,
            TransformKind::Rotation => {
                DQuat::from_euler(
                    EulerRot::XYZ,
                    (components.x as f64).to_radians(),
                    (components.y as f64).to_radians(),
                    (components.z as f64).to_radians(),
                ) * v
            }
            TransformKind::Scale => v * offset,
        };
        let new_origin = match self.kind {
            TransformKind::Position => origin + offset,
            _ => center + transform(origin - center),
        };
        let new_right = transform(right).normalize_or_zero();
        let transformed_up = transform(up);
        let new_up =
            (transformed_up - new_right * transformed_up.dot(new_right)).normalize_or_zero();
        let new_normal = new_right.cross(new_up);
        if !new_origin.is_finite()
            || new_right.length_squared() < 0.5
            || new_up.length_squared() < 0.5
        {
            return None;
        }
        profile.workplane.origin = new_origin.to_array();
        profile.workplane.right = new_right.to_array();
        profile.workplane.up = new_up.to_array();
        profile.workplane.normal = new_normal.to_array();
        for point in &mut spline.points {
            let p = right * point.position[0] + up * point.position[1];
            let next = transform(p);
            point.position = [next.dot(new_right), next.dot(new_up), 0.0];
            for handle in [&mut point.handle_in, &mut point.handle_out] {
                let value = transform(right * handle[0] + up * handle[1]);
                *handle = [value.dot(new_right), value.dot(new_up), 0.0];
            }
        }
        profile.validate_authoring(&spline).ok()?;
        Some((profile, spline))
    }
}

impl<V: PetuniaViewport> SlintUiBridge<V> {
    fn restore_profile_object_source(&mut self, session: &ProfileObjectTransform) {
        let project = &mut self.state.project.project;
        if let Some(profile) = project.get_profile_mut(session.id) {
            *profile = session.profile.clone();
        }
        if let Some(spline) = project.get_spline_mut(session.spline.id) {
            *spline = session.spline.clone();
        }
        project.bump_changes(ProjectChanges::SPLINES | ProjectChanges::PROCEDURAL);
        self.state.mark_dirty();
    }
    pub(crate) fn profile_part_selected(&self) -> bool {
        self.selected_profile_id
            .is_some_and(|id| self.state.project.project.get_profile(id).is_some())
    }

    pub(crate) fn select_profile_part(&mut self, id: uuid::Uuid) -> bool {
        if self.state.project.project.get_profile(id).is_none()
            || !self.state.project.project.profile_visible(id)
            || self.state.project.project.profile_locked(id)
        {
            return false;
        }
        self.cancel_profile_object_transform();
        if self.modeling_mode != crate::ModelingMode::Draw {
            self.apply(crate::UiIntent::SetModelingMode(crate::ModelingMode::Draw));
        }
        self.state
            .set_selection_domain(petunia_core::SelectionDomain::Object);
        self.selected_profile_id = Some(id);
        self.activate_profile(id);
        self.reset_transform_fields();
        self.state.project.project.bump_selection();
        self.state.mark_dirty();
        true
    }

    pub(crate) fn clear_profile_part_selection(&mut self) {
        if self.selected_profile_id.take().is_some() {
            self.cancel_profile_object_transform();
            self.state.project.project.bump_selection();
            self.state.mark_dirty();
        }
    }

    pub(crate) fn delete_profile_part(&mut self) -> bool {
        let Some(id) = self.selected_profile_id else {
            return false;
        };
        match self
            .state
            .dispatch(&petunia_core::DeleteProfileCmd { profile_id: id })
        {
            Ok(()) => {
                self.selected_profile_id = None;
                if self.active_profile_id == Some(id) {
                    self.active_profile_id = None;
                }
                self.state.mark_dirty();
                true
            }
            Err(error) => {
                self.state.set_status(error.to_string());
                false
            }
        }
    }

    pub(crate) fn duplicate_profile_part(&mut self) -> bool {
        let Some(id) = self.selected_profile_id else {
            return false;
        };
        let project = &self.state.project.project;
        let Some(mut profile) = project.get_profile(id).cloned() else {
            return false;
        };
        let Some(mut spline) = project.get_spline(profile.spline_id).cloned() else {
            return false;
        };
        spline.id = uuid::Uuid::new_v4();
        for point in &mut spline.points {
            point.id = uuid::Uuid::new_v4();
        }
        spline.revision = 0;
        profile.id = uuid::Uuid::new_v4();
        profile.spline_id = spline.id;
        profile.revision = 0;
        profile.name = format!("{}_copy", profile.name);
        profile.workplane.origin[0] += 0.5;
        let new_id = profile.id;
        match self
            .state
            .dispatch(&petunia_core::CreateProfileCmd { spline, profile })
        {
            Ok(()) => self.select_profile_part(new_id),
            Err(error) => {
                self.state.set_status(error.to_string());
                false
            }
        }
    }

    pub(crate) fn profile_part_pivot(&self) -> Option<Vec3> {
        let id = self.selected_profile_id?;
        let project = &self.state.project.project;
        let profile = project.get_profile(id)?;
        let spline = project.get_spline(profile.spline_id)?;
        if spline.points.is_empty() {
            return None;
        }
        let origin = DVec3::from_array(profile.workplane.origin);
        let right = DVec3::from_array(profile.workplane.right);
        let up = DVec3::from_array(profile.workplane.up);
        let center = spline
            .points
            .iter()
            .map(|point| origin + right * point.position[0] + up * point.position[1])
            .sum::<DVec3>()
            / spline.points.len() as f64;
        Some(center.as_vec3())
    }

    pub(crate) fn begin_profile_object_transform(&mut self, kind: TransformKind) -> bool {
        let Some(session) = ProfileObjectTransform::new(self, kind) else {
            return false;
        };
        self.profile_object_transform = Some(session);
        self.reset_transform_fields();
        true
    }

    pub(crate) fn update_profile_object_transform(&mut self, components: Vec3) -> bool {
        let Some(session) = self.profile_object_transform.as_mut() else {
            return false;
        };
        let Some((mut profile, mut spline)) = session.geometry(components) else {
            return false;
        };
        let project = &mut self.state.project.project;
        let Some(current_profile) = project.get_profile_mut(session.id) else {
            return false;
        };
        profile.revision = current_profile.revision.wrapping_add(1);
        *current_profile = profile;
        let Some(current_spline) = project.get_spline_mut(spline.id) else {
            return false;
        };
        spline.revision = current_spline.revision.wrapping_add(1);
        *current_spline = spline;
        project.bump_changes(ProjectChanges::SPLINES | ProjectChanges::PROCEDURAL);
        session.components = components;
        self.state.mark_dirty();
        true
    }

    pub(crate) fn commit_profile_object_transform(&mut self) -> bool {
        let Some(session) = self.profile_object_transform.take() else {
            return false;
        };
        if session.components
            == if session.kind == TransformKind::Scale {
                Vec3::ONE
            } else {
                Vec3::ZERO
            }
        {
            self.restore_profile_object_source(&session);
            return false;
        }
        let project = &self.state.project.project;
        let Some(profile) = project.get_profile(session.id).cloned() else {
            return false;
        };
        let Some(spline) = project.get_spline(profile.spline_id).cloned() else {
            return false;
        };
        self.restore_profile_object_source(&session);
        match self
            .state
            .dispatch(&petunia_core::TransformProfileCmd { profile, spline })
        {
            Ok(()) => true,
            Err(error) => {
                self.state.set_status(error.to_string());
                false
            }
        }
    }

    pub(crate) fn cancel_profile_object_transform(&mut self) -> bool {
        let Some(session) = self.profile_object_transform.take() else {
            return false;
        };
        self.restore_profile_object_source(&session);
        true
    }

    pub(crate) fn profile_part_at(
        &self,
        normalized_x: f32,
        normalized_y: f32,
    ) -> Option<uuid::Uuid> {
        if self.state.workspace != petunia_core::Workspace::Model
            || self.modeling_mode != crate::ModelingMode::Draw
        {
            return None;
        }
        let pixel = [
            normalized_x * self.viewport_size[0],
            normalized_y * self.viewport_size[1],
        ];
        let cache = self.shape_cache();
        let camera = &self.state.session.camera;
        for line in cache.lines.iter().rev() {
            if self.state.project.project.profile_locked(line.id) {
                continue;
            }
            if line.world.len() < 2 {
                continue;
            }
            let points: Vec<_> = line
                .world
                .iter()
                .map(|p| crate::projection::project_world_point(camera, self.viewport_size, *p))
                .collect();
            let mut near_edge = false;
            let mut inside = false;
            let count = points.len();
            for i in 0..count {
                let j = (i + 1) % count;
                if !line.closed && j == 0 {
                    break;
                }
                let (Some(a), Some(b)) = (points[i], points[j]) else {
                    continue;
                };
                if crate::draw_shapes::point_segment_distance(pixel, a, b).0
                    <= crate::draw_shapes::SHAPE_HIT_RADIUS_PX
                {
                    near_edge = true;
                }
                if line.closed
                    && ((a[1] > pixel[1]) != (b[1] > pixel[1]))
                    && pixel[0] < (b[0] - a[0]) * (pixel[1] - a[1]) / (b[1] - a[1]) + a[0]
                {
                    inside = !inside;
                }
            }
            if near_edge || inside {
                return Some(line.id);
            }
        }
        None
    }

    pub(crate) fn profile_drag_components(&self, current: [f32; 2]) -> Option<Vec3> {
        let session = self.profile_object_transform.as_ref()?;
        let drag = self.drag?;
        let delta = Vec2::new(current[0] - drag.start[0], current[1] - drag.start[1]);
        let pivot = self.profile_part_pivot()?;
        let camera = &self.state.session.camera;
        let viewport = Vec2::from_array(self.viewport_size);
        let start = Vec2::from_array(drag.start);
        let end = Vec2::from_array(current);
        let axis = match self.gizmo_drag {
            Some(crate::GizmoHandle::X) => Some(0),
            Some(crate::GizmoHandle::Y) => Some(1),
            Some(crate::GizmoHandle::Z) => Some(2),
            _ => None,
        };
        match session.kind {
            TransformKind::Position => {
                if let Some(axis) = axis {
                    let unit = [Vec3::X, Vec3::Y, Vec3::Z][axis];
                    let distance = petunia_core::transform_projection::axis_delta(
                        camera, viewport, start, end, pivot, unit,
                    )?;
                    Some(unit * distance)
                } else {
                    petunia_core::transform_projection::plane_delta(
                        camera,
                        viewport,
                        start,
                        end,
                        pivot,
                        camera.forward(),
                    )
                }
            }
            TransformKind::Rotation => {
                let axis = axis.unwrap_or(2);
                let unit = [Vec3::X, Vec3::Y, Vec3::Z][axis];
                let angle = petunia_core::transform_projection::rotation_angle(
                    camera, viewport, start, end, pivot, unit,
                )
                .unwrap_or(delta.x * 0.5);
                Some(unit * angle)
            }
            TransformKind::Scale => {
                let factor = (1.0 + delta.x * 0.005).max(0.001);
                let mut factors = Vec3::ONE;
                if let Some(axis) = axis {
                    factors[axis] = factor;
                } else {
                    factors = Vec3::splat(factor);
                }
                Some(factors)
            }
        }
    }
}
