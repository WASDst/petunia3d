# ADR 008 — Modularização do frontend Slint (`petunia_ui_slint`)

Status: **aceito como plano de trabalho em 2026-10-01** pelo responsável do produto (plano de refatoração aprovado na sessão de GUI). A **Fase 8** (mover lógica de domínio para fora do crate de UI) e as mudanças visuais da **Fase 4** ainda exigem aceite explícito antes de começar.
Autoridade: [AGENTS.md §0.1 e §2](../../../AGENTS.md), [capítulo 36](../../bible/foundations/36-ui-baseline-temas-plugin-panels.md), [constituição 03](../../bible/constitution/03-invariantes-de-ui-ux-design-system-e-acessib.md) e [capítulo 46](../../bible/foundations/46-pesquisa-interacao-modelagem-referencias.md) (pergunta sobre os monólitos `app.slint` e `lib.rs`).
Este ADR registra o motivo; não cria uma segunda baseline nem reabre a UI Baseline V1.

## Contexto

A auditoria de 2026-09-30/10-01 do crate `crates/ui-slint/` (~52 mil linhas, 156 commits em dez dias) mostrou:

1. **Monólitos.** `ui/app.slint` (12,5k linhas; `PetuniaSlintShell` tem 9,3k linhas, 651 propriedades e 265 callbacks), `src/lib.rs` (13,2k; um `impl SlintUiBridge` de ~12k linhas e 87 campos), `src/callbacks.rs` (5,2k; `connect_callbacks` com 4,0k linhas e 259 closures; `sync_window_properties` com 516 setters), `ShellViewModel` com ~500 campos planos e `src/tests.rs` (9,6k linhas, 339 testes).
2. **Componentização insuficiente.** Quatro botões-ícone quase idênticos, passos +/− refeitos à mão, 63 ternários accent/surface, painéis flutuantes sem chrome compartilhado.
3. **Tokens incompletos.** `control-height` nunca é usado; não há escala tipográfica nem raios `segment/window/pill`; 230 alturas fixas abaixo de 28 px, 59 textos de 8/9 px, 130 hex soltos no shell e ~42 literais sem `Tr.t`, contra o cap. 36 e a constituição 03.
4. **Ciclo de módulos pela raiz.** `view_model`, `projection` e `callbacks` fazem `use crate::*`; tipos de domínio (perfil/Draw, loop cut, knife, parâmetros de primitivos, pincel) vivem no crate de UI.
5. **Sem gate.** Nenhum workflow cobria `crates/ui-slint/`; o `ui-guard` vale só para o egui legado.

## Decisão

1. **Refatorar antes de evoluir a GUI**, em fases pequenas, cada uma com um commit por passo: baseline e rede de segurança → reorganizar testes → fatiar o `impl` do bridge → fatiar callbacks e sincronização → tokens e primitivos → fatiar `app.slint` → tipos no lugar de strings → agrupar o `ShellViewModel` → (aprovação própria) domínio fora da UI → documentação.
2. **Sem mudar comportamento nos commits de refatoração.** Mudanças visuais ficam em commits separados, rotulados `visual:`.
3. **Contratos preservados:** `petunia_ui_slint::run()` e a feature `animation-workspace`; `PetuniaSlintShell`, `SlintUiBridge`, `PlaceholderViewport`, `UiIntent`, `SceneItem`, `tr::install`, `animate::*`; `DesignTokens`, `Tr`, `Motion`; `ui/app.slint` como raiz de compilação; **rótulos acessíveis não são renomeados**.
4. **`UiIntent` continua sendo a única fronteira** com o domínio; callbacks que chamam o bridge diretamente migram para intents à medida que cada painel é dividido.
5. **Padrões de divisão já existentes são o modelo:** `animate.rs`/`animate.slint` (fatia vertical) para Rust e Slint; segundo `impl SlintUiBridge` em arquivo próprio.
6. **Tokens em três camadas** (global → semântico → componente) e primitivos com contrato escrito (props, estados, teclado, acessibilidade).
7. **O gate vira parte do produto:** workflow `ui-slint.yml` (fmt, clippy `-D warnings`, testes do crate), golden master da árvore acessível (`src/contract_tests.rs`) e varredura de chaves `Tr.t` em todos os `ui/**/*.slint`.

### Metas mensuráveis

- `app.slint` ≤ ~400 linhas; nenhum arquivo de produção (`.slint` ou `.rs`) > ~1.500 linhas; nenhuma função > ~150 linhas (exceto tabelas `match` justificadas).
- 0 `font-size` < 10 px; 0 hex fora de `tokens.slint`; 0 literal de texto sem `Tr.t` (glifos nomeados); alvo mínimo 24 px, controle padrão 28 px.
- 0 `use crate::*` em módulos internos; campos do bridge `pub(crate)`.
- Número de testes ≥ baseline e todos verdes em cada commit.

## Consequências

- **Positivas:** controles e tokens passam a ter um dono único; conformidade com o cap. 36 deixa de depender de cada tela; o shell é testável por painel; conflitos de merge diminuem; o gate cobre o crate de produção.
- **Custos e riscos:** dezenas de commits pequenos; o teste de chaves e o golden precisam acompanhar cada divisão; mudanças visuais exigem revisão com capturas antes/depois; branches paralelas ativas podem conflitar (sincronizar com `main` com frequência).
- **Não aprovado por este ADR:** mover domínio para `petunia_core` (Fase 8), alterar a UI Baseline V1, tocar o site público congelado ou o `docs/public/ui-map.json` (que só referencia `crates/ui/`).
