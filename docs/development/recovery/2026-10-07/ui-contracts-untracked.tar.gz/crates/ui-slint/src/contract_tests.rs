//! Testes de caracterização do shell (golden master).
//!
//! Protegem a refatoração modular (ADR 008): dividir `app.slint`, `callbacks.rs` e
//! `sync_window_properties` não pode alterar o que o shell expõe ao usuário nem às
//! tecnologias assistivas. O golden registra, por workspace, a árvore de elementos
//! acessíveis (papel, rótulo, valor, estado) depois de `sync_window_properties` sobre
//! um `ShellViewModel` real. Um setter perdido ou um rótulo renomeado muda o golden.
//!
//! Para aceitar uma mudança intencional: `UPDATE_GOLDEN=1 cargo test -p petunia_ui_slint
//! --lib contract_tests` e revisar o diff do arquivo em `tests/golden/`.

use std::collections::BTreeSet;
use std::path::PathBuf;

use i_slint_backend_testing::{ElementHandle, ElementQuery};
use slint::{ComponentHandle, LogicalSize};

use crate::{
    PetuniaSlintShell, PlaceholderViewport, SlintUiBridge, callbacks::sync_window_properties, tr,
};
use petunia_core::AppState;

const WORKSPACES: &[&str] = &[
    "MODEL",
    "PAINT",
    "UV",
    #[cfg(feature = "animation-workspace")]
    "ANIMATE",
];

fn golden_path() -> PathBuf {
    let name = if cfg!(feature = "animation-workspace") {
        "a11y_contract_animate.txt"
    } else {
        "a11y_contract.txt"
    };
    PathBuf::from(env!("CARGO_MANIFEST_DIR"))
        .join("tests")
        .join("golden")
        .join(name)
}

/// Uma linha estável por elemento acessível nomeado.
fn describe(element: &ElementHandle) -> Option<String> {
    let label = element.accessible_label().filter(|l| !l.is_empty())?;
    let role = element
        .accessible_role()
        .map_or_else(|| "none".to_string(), |r| format!("{r:?}"));
    let mut line = format!("{role} | {label}");
    if let Some(value) = element.accessible_value().filter(|v| !v.is_empty()) {
        line.push_str(&format!(" | value={value}"));
    }
    if let Some(checked) = element.accessible_checked() {
        line.push_str(&format!(" | checked={checked}"));
    }
    if element.accessible_enabled() == Some(false) {
        line.push_str(" | disabled");
    }
    Some(line)
}

fn snapshot() -> String {
    let shell = PetuniaSlintShell::new().expect("Slint shell");
    tr::install(&shell, "en");
    shell.window().set_size(LogicalSize::new(1280.0, 800.0));
    shell.show().expect("headless window");

    let bridge = SlintUiBridge::new(AppState::default(), PlaceholderViewport::default());
    let view_model = bridge.view_model();
    sync_window_properties(&shell, &view_model);

    let mut out = String::new();
    for workspace in WORKSPACES {
        shell.set_active_workspace((*workspace).into());
        let lines: BTreeSet<String> = ElementQuery::from_root(&shell)
            .match_descendants()
            .match_predicate(|e| e.accessible_label().is_some_and(|l| !l.is_empty()))
            .find_all()
            .iter()
            .filter_map(describe)
            .collect();
        out.push_str(&format!("## {workspace} ({} elementos)\n", lines.len()));
        for line in lines {
            out.push_str(&line);
            out.push('\n');
        }
        out.push('\n');
    }
    out
}

#[test]
fn accessible_tree_matches_golden_after_sync() {
    i_slint_backend_testing::init_no_event_loop();
    let actual = snapshot();
    let path = golden_path();
    if std::env::var_os("UPDATE_GOLDEN").is_some() {
        std::fs::create_dir_all(path.parent().expect("pasta golden")).expect("criar golden/");
        std::fs::write(&path, &actual).expect("gravar golden");
        return;
    }
    let expected = std::fs::read_to_string(&path).unwrap_or_else(|_| {
        panic!(
            "golden ausente em {}; gere com UPDATE_GOLDEN=1",
            path.display()
        )
    });
    assert_eq!(
        actual,
        expected,
        "árvore acessível mudou; se for intencional, UPDATE_GOLDEN=1 e revise {}",
        path.display()
    );
}

/// Cada captura roda em uma thread própria: o catálogo de `tr::install` e a plataforma de
/// teste do Slint são `thread_local`, então uma segunda janela na mesma thread não receberia
/// o `Tr.lookup` e perderia os rótulos.
fn snapshot_in_fresh_thread() -> String {
    std::thread::spawn(|| {
        i_slint_backend_testing::init_no_event_loop();
        snapshot()
    })
    .join()
    .expect("captura sem panic")
}

#[test]
fn accessible_tree_is_deterministic() {
    assert_eq!(snapshot_in_fresh_thread(), snapshot_in_fresh_thread());
}
