//! Pontas de pincel por imagem e importação de bibliotecas (ADR 008).
//!
//! Uma ponta é uma imagem em tons de cinza (`255` = tinta plena). O motor de
//! pintura a amostra girada e achatada como as pontas geométricas. Os
//! importadores leem PNG/JPEG, SVG, GBR (GIMP) e ABR (Photoshop, versões 1, 2
//! e 6+, pontas amostradas). Todo arquivo é tratado como não confiável: leitura
//! com limites, sem pânico, erro em vez de dado parcial silencioso.

use serde::{Deserialize, Serialize};

use crate::Canvas;

/// Maior lado de uma ponta guardada (pontas maiores são reduzidas).
pub const MAX_TIP_SIDE: u32 = 256;
/// Maior lado aceito num arquivo importado, antes da redução.
const MAX_SOURCE_SIDE: u32 = 8192;
/// Teto de bytes de pixels por ponta lida de um arquivo.
const MAX_SOURCE_BYTES: usize = 128 * 1024 * 1024;
/// Teto de pontas por arquivo.
const MAX_TIPS_PER_FILE: usize = 2048;

/// Imagem de ponta em tons de cinza, linha a linha, origem em cima.
#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub struct TipImage {
    pub w: u32,
    pub h: u32,
    #[serde(with = "crate::pixel_bytes")]
    pub alpha: Vec<u8>,
}

impl TipImage {
    /// Nova ponta; `None` se as dimensões não batem com os dados.
    pub fn new(w: u32, h: u32, alpha: Vec<u8>) -> Option<Self> {
        (w > 0 && h > 0 && alpha.len() == (w as usize) * (h as usize)).then_some(Self {
            w,
            h,
            alpha,
        })
    }

    /// Ponta a partir de RGBA: usa o alfa quando há transparência; numa imagem
    /// opaca, o escuro vira tinta (pincel preto sobre papel branco).
    pub fn from_rgba(w: u32, h: u32, rgba: &[u8]) -> Option<Self> {
        if rgba.len() != (w as usize) * (h as usize) * 4 {
            return None;
        }
        let translucent = rgba.chunks_exact(4).any(|px| px[3] < 250);
        let alpha = rgba
            .chunks_exact(4)
            .map(|px| {
                if translucent {
                    px[3]
                } else {
                    let lum = 0.2126 * px[0] as f32 + 0.7152 * px[1] as f32 + 0.0722 * px[2] as f32;
                    (255.0 - lum).round().clamp(0.0, 255.0) as u8
                }
            })
            .collect();
        Self::new(w, h, alpha)
    }

    /// Ponta a partir de um canvas RGBA (ver [`Self::from_rgba`]).
    pub fn from_canvas(canvas: &Canvas) -> Option<Self> {
        Self::from_rgba(canvas.w, canvas.h, &canvas.pixels)
    }

    /// Cobertura em `(u, v)` ∈ `[-1, 1]²`, com a imagem centrada no quadrado
    /// unitário pelo maior lado. Bilinear; fora da imagem = `0`.
    pub fn sample(&self, u: f32, v: f32) -> f32 {
        let side = self.w.max(self.h) as f32;
        let x = (u * 0.5 + 0.5) * side - (side - self.w as f32) * 0.5 - 0.5;
        let y = (v * 0.5 + 0.5) * side - (side - self.h as f32) * 0.5 - 0.5;
        if !(x.is_finite() && y.is_finite()) || x < -1.0 || y < -1.0 {
            return 0.0;
        }
        let (x0, y0) = (x.floor(), y.floor());
        let (fx, fy) = (x - x0, y - y0);
        let texel = |xi: f32, yi: f32| -> f32 {
            if xi < 0.0 || yi < 0.0 || xi >= self.w as f32 || yi >= self.h as f32 {
                return 0.0;
            }
            self.alpha[(yi as usize) * self.w as usize + xi as usize] as f32 / 255.0
        };
        let top = texel(x0, y0) * (1.0 - fx) + texel(x0 + 1.0, y0) * fx;
        let bottom = texel(x0, y0 + 1.0) * (1.0 - fx) + texel(x0 + 1.0, y0 + 1.0) * fx;
        top * (1.0 - fy) + bottom * fy
    }

    /// Identidade estável do conteúdo (FNV-1a 64), usada como id da ponta.
    pub fn content_hash(&self) -> u64 {
        let mut hash: u64 = 0xcbf2_9ce4_8422_2325;
        let mut feed = |byte: u8| {
            hash ^= byte as u64;
            hash = hash.wrapping_mul(0x0100_0000_01b3);
        };
        for byte in self.w.to_le_bytes().into_iter().chain(self.h.to_le_bytes()) {
            feed(byte);
        }
        for &byte in &self.alpha {
            feed(byte);
        }
        // `0` significa "sem ponta" no estilo do pincel.
        hash.max(1)
    }

    /// Inverte quando a borda é clara: arquivos que guardam o pincel como
    /// preto sobre branco viram tinta sobre transparente.
    pub fn normalize_polarity(&mut self) {
        let (w, h) = (self.w as usize, self.h as usize);
        let mut sum = 0u64;
        let mut count = 0u64;
        for y in 0..h {
            for x in 0..w {
                if x == 0 || y == 0 || x + 1 == w || y + 1 == h {
                    sum += self.alpha[y * w + x] as u64;
                    count += 1;
                }
            }
        }
        if count > 0 && sum / count > 127 {
            for value in &mut self.alpha {
                *value = 255 - *value;
            }
        }
    }

    /// Reduz por média de caixa até o maior lado caber em `max_side`.
    pub fn fit(self, max_side: u32) -> Self {
        let side = self.w.max(self.h);
        if side <= max_side || max_side == 0 {
            return self;
        }
        let scale = side as f32 / max_side as f32;
        let nw = ((self.w as f32 / scale).round() as u32).max(1);
        let nh = ((self.h as f32 / scale).round() as u32).max(1);
        let mut out = vec![0u8; (nw * nh) as usize];
        for ny in 0..nh {
            for nx in 0..nw {
                let (sx0, sy0) = ((nx as f32 * scale) as u32, (ny as f32 * scale) as u32);
                let sx1 = (((nx + 1) as f32 * scale) as u32).clamp(sx0 + 1, self.w);
                let sy1 = (((ny + 1) as f32 * scale) as u32).clamp(sy0 + 1, self.h);
                let mut sum = 0u32;
                let mut n = 0u32;
                for sy in sy0..sy1 {
                    for sx in sx0..sx1 {
                        sum += self.alpha[(sy * self.w + sx) as usize] as u32;
                        n += 1;
                    }
                }
                out[(ny * nw + nx) as usize] = (sum / n.max(1)) as u8;
            }
        }
        Self {
            w: nw,
            h: nh,
            alpha: out,
        }
    }

    /// Prévia RGBA (tinta branca sobre transparente), para miniaturas.
    pub fn to_canvas(&self) -> Canvas {
        let mut canvas = Canvas::new(self.w, self.h, [0, 0, 0, 0]);
        for (index, &a) in self.alpha.iter().enumerate() {
            canvas.pixels[index * 4..index * 4 + 4].copy_from_slice(&[255, 255, 255, a]);
        }
        canvas
    }
}

/// Uma ponta lida de um arquivo.
#[derive(Clone, Debug, PartialEq)]
pub struct ImportedTip {
    pub name: String,
    pub tip: TipImage,
    /// Espaçamento entre carimbos, fração do diâmetro, quando o arquivo traz.
    pub spacing: Option<f32>,
}

/// Resultado de uma importação: pontas e avisos para o relatório.
#[derive(Clone, Debug, Default, PartialEq)]
pub struct TipImport {
    pub tips: Vec<ImportedTip>,
    /// O que foi ignorado (pincéis computados, dinâmica do ABR, etc.).
    pub notes: Vec<String>,
}

#[derive(Debug, PartialEq, Eq)]
pub enum TipImportError {
    /// Formato não reconhecido pela extensão nem pelo conteúdo.
    UnknownFormat,
    /// Arquivo truncado ou campo inconsistente.
    Malformed(&'static str),
    /// Versão ou profundidade de cor fora do que é lido.
    Unsupported(String),
    /// Imagem grande demais.
    TooLarge,
    /// O arquivo é válido, mas não tem nenhuma ponta amostrada.
    Empty,
}

impl std::fmt::Display for TipImportError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::UnknownFormat => f.write_str("formato de pincel não reconhecido"),
            Self::Malformed(what) => write!(f, "arquivo de pincel corrompido: {what}"),
            Self::Unsupported(what) => write!(f, "pincel não suportado: {what}"),
            Self::TooLarge => f.write_str("imagem de pincel grande demais"),
            Self::Empty => f.write_str("nenhuma ponta de pincel no arquivo"),
        }
    }
}

impl std::error::Error for TipImportError {}

/// Importa pontas de `bytes`. `file_name` serve de dica de formato e de nome.
pub fn import_tips(bytes: &[u8], file_name: &str) -> Result<TipImport, TipImportError> {
    let lower = file_name.to_ascii_lowercase();
    let stem = std::path::Path::new(file_name)
        .file_stem()
        .map(|stem| stem.to_string_lossy().into_owned())
        .filter(|stem| !stem.is_empty())
        .unwrap_or_else(|| "Brush".to_string());
    let mut import = if lower.ends_with(".abr") {
        import_abr(bytes, &stem)?
    } else if lower.ends_with(".gbr") || bytes.get(20..24) == Some(b"GIMP") {
        import_gbr(bytes, &stem)?
    } else if lower.ends_with(".svg") || looks_like_svg(bytes) {
        import_svg(bytes, &stem)?
    } else if bytes.starts_with(&[0x89, b'P', b'N', b'G']) || bytes.starts_with(&[0xFF, 0xD8]) {
        import_image(bytes, &stem)?
    } else {
        return Err(TipImportError::UnknownFormat);
    };
    if import.tips.is_empty() {
        return Err(TipImportError::Empty);
    }
    for tip in &mut import.tips {
        let fitted = std::mem::replace(
            &mut tip.tip,
            TipImage {
                w: 1,
                h: 1,
                alpha: vec![0],
            },
        );
        tip.tip = fitted.fit(MAX_TIP_SIDE);
    }
    Ok(import)
}

fn looks_like_svg(bytes: &[u8]) -> bool {
    let head = &bytes[..bytes.len().min(512)];
    let text = String::from_utf8_lossy(head);
    text.contains("<svg")
}

fn import_image(bytes: &[u8], stem: &str) -> Result<TipImport, TipImportError> {
    let image = image::load_from_memory(bytes)
        .map_err(|_| TipImportError::Malformed("imagem ilegível"))?
        .to_rgba8();
    let (w, h) = image.dimensions();
    if w > MAX_SOURCE_SIDE || h > MAX_SOURCE_SIDE {
        return Err(TipImportError::TooLarge);
    }
    let tip =
        TipImage::from_rgba(w, h, image.as_raw()).ok_or(TipImportError::Malformed("dimensões"))?;
    Ok(TipImport {
        tips: vec![ImportedTip {
            name: stem.to_string(),
            tip,
            spacing: None,
        }],
        notes: Vec::new(),
    })
}

fn import_svg(bytes: &[u8], stem: &str) -> Result<TipImport, TipImportError> {
    let text =
        std::str::from_utf8(bytes).map_err(|_| TipImportError::Malformed("SVG não é UTF-8"))?;
    let canvas = crate::svg::rasterize_svg(text, MAX_TIP_SIDE)
        .map_err(|_| TipImportError::Malformed("SVG inválido"))?;
    let tip = TipImage::from_canvas(&canvas).ok_or(TipImportError::Malformed("dimensões"))?;
    Ok(TipImport {
        tips: vec![ImportedTip {
            name: stem.to_string(),
            tip,
            spacing: None,
        }],
        notes: Vec::new(),
    })
}

/// Leitor big-endian sem pânico.
struct Reader<'a> {
    data: &'a [u8],
    pos: usize,
}

impl<'a> Reader<'a> {
    fn new(data: &'a [u8]) -> Self {
        Self { data, pos: 0 }
    }

    fn bytes(&mut self, n: usize) -> Result<&'a [u8], TipImportError> {
        let end = self
            .pos
            .checked_add(n)
            .ok_or(TipImportError::Malformed("tamanho"))?;
        let slice = self
            .data
            .get(self.pos..end)
            .ok_or(TipImportError::Malformed("fim inesperado"))?;
        self.pos = end;
        Ok(slice)
    }

    fn u8(&mut self) -> Result<u8, TipImportError> {
        Ok(self.bytes(1)?[0])
    }

    fn u16(&mut self) -> Result<u16, TipImportError> {
        let b = self.bytes(2)?;
        Ok(u16::from_be_bytes([b[0], b[1]]))
    }

    fn u32(&mut self) -> Result<u32, TipImportError> {
        let b = self.bytes(4)?;
        Ok(u32::from_be_bytes([b[0], b[1], b[2], b[3]]))
    }

    fn i32(&mut self) -> Result<i32, TipImportError> {
        Ok(self.u32()? as i32)
    }

    fn skip(&mut self, n: usize) -> Result<(), TipImportError> {
        self.bytes(n).map(|_| ())
    }

    fn seek(&mut self, pos: usize) -> Result<(), TipImportError> {
        if pos > self.data.len() {
            return Err(TipImportError::Malformed("posição"));
        }
        self.pos = pos;
        Ok(())
    }

    fn remaining(&self) -> usize {
        self.data.len().saturating_sub(self.pos)
    }
}

fn checked_dims(w: u32, h: u32, bytes_per_px: usize) -> Result<usize, TipImportError> {
    if w == 0 || h == 0 {
        return Err(TipImportError::Malformed("dimensão zero"));
    }
    if w > MAX_SOURCE_SIDE || h > MAX_SOURCE_SIDE {
        return Err(TipImportError::TooLarge);
    }
    let total = (w as usize) * (h as usize) * bytes_per_px;
    if total > MAX_SOURCE_BYTES {
        return Err(TipImportError::TooLarge);
    }
    Ok(total)
}

/// GBR do GIMP, versões 1 a 3: cabeçalho, nome, pixels (cinza ou RGBA).
fn import_gbr(bytes: &[u8], stem: &str) -> Result<TipImport, TipImportError> {
    let mut r = Reader::new(bytes);
    let header_size = r.u32()? as usize;
    let version = r.u32()?;
    let w = r.u32()?;
    let h = r.u32()?;
    let bpp = r.u32()? as usize;
    let (fixed, spacing) = match version {
        1 => (20, None),
        2 | 3 => {
            if r.bytes(4)? != b"GIMP" {
                return Err(TipImportError::Malformed("assinatura GIMP"));
            }
            (28, Some(r.u32()? as f32 / 100.0))
        }
        other => return Err(TipImportError::Unsupported(format!("GBR versão {other}"))),
    };
    if header_size < fixed || header_size > bytes.len() {
        return Err(TipImportError::Malformed("cabeçalho"));
    }
    let name_bytes = r.bytes(header_size - fixed)?;
    let name = String::from_utf8_lossy(name_bytes)
        .trim_end_matches('\0')
        .trim()
        .to_string();
    if !matches!(bpp, 1 | 4) {
        return Err(TipImportError::Unsupported(format!(
            "GBR com {bpp} bytes por pixel"
        )));
    }
    let total = checked_dims(w, h, bpp)?;
    let data = r.bytes(total)?;
    let tip = if bpp == 1 {
        TipImage::new(w, h, data.to_vec())
    } else {
        // Pincel colorido: a forma está no alfa.
        TipImage::new(w, h, data.chunks_exact(4).map(|px| px[3]).collect())
    }
    .ok_or(TipImportError::Malformed("dimensões"))?;
    let mut notes = Vec::new();
    if bpp == 4 {
        notes.push("cor do pincel GBR ignorada: só a forma é usada".to_string());
    }
    Ok(TipImport {
        tips: vec![ImportedTip {
            name: if name.is_empty() {
                stem.to_string()
            } else {
                name
            },
            tip,
            spacing: spacing.filter(|s| *s > 0.0),
        }],
        notes,
    })
}

/// ABR do Photoshop: versões 1 e 2 (lista de pincéis) e 6+ (seção `samp`).
fn import_abr(bytes: &[u8], stem: &str) -> Result<TipImport, TipImportError> {
    let mut r = Reader::new(bytes);
    let version = r.u16()?;
    let mut import = match version {
        1 | 2 => import_abr_v12(&mut r, version, stem)?,
        6 | 7 | 10 => {
            let subversion = r.u16()?;
            import_abr_v6(&mut r, subversion, stem)?
        }
        other => return Err(TipImportError::Unsupported(format!("ABR versão {other}"))),
    };
    import
        .notes
        .push("dinâmica do ABR (dispersão, textura, pincel duplo) não é importada".to_string());
    for tip in &mut import.tips {
        tip.tip.normalize_polarity();
    }
    Ok(import)
}

fn import_abr_v12(r: &mut Reader, version: u16, stem: &str) -> Result<TipImport, TipImportError> {
    let count = r.u16()? as usize;
    let mut import = TipImport::default();
    let mut computed = 0;
    for index in 0..count.min(MAX_TIPS_PER_FILE) {
        let kind = r.u16()?;
        let size = r.u32()? as usize;
        let next = r
            .pos
            .checked_add(size)
            .ok_or(TipImportError::Malformed("tamanho"))?;
        match kind {
            1 => computed += 1,
            2 => {
                r.skip(4)?; // misc
                let spacing = r.u16()? as f32 / 100.0;
                let mut name = if version == 2 {
                    read_ucs2(r)?
                } else {
                    String::new()
                };
                r.skip(1)?; // antialiasing
                r.skip(8)?; // limites curtos
                let (top, left, bottom, right) = (r.i32()?, r.i32()?, r.i32()?, r.i32()?);
                let depth = r.u16()?;
                let compressed = r.u8()? != 0;
                let tip = read_abr_bitmap(r, top, left, bottom, right, depth, compressed)?;
                if name.is_empty() {
                    name = format!("{stem} {}", index + 1);
                }
                import.tips.push(ImportedTip {
                    name,
                    tip,
                    spacing: (spacing > 0.0).then_some(spacing),
                });
            }
            other => {
                import
                    .notes
                    .push(format!("tipo de pincel ABR {other} ignorado"));
            }
        }
        r.seek(next)?;
    }
    if computed > 0 {
        import.notes.push(format!(
            "{computed} pincel(is) computado(s) do ABR ignorado(s): use as pontas geométricas"
        ));
    }
    Ok(import)
}

fn import_abr_v6(r: &mut Reader, subversion: u16, stem: &str) -> Result<TipImport, TipImportError> {
    // Percorre as seções `8BIM` até a de amostras.
    let section_end = loop {
        if r.remaining() < 12 {
            return Err(TipImportError::Empty);
        }
        if r.bytes(4)? != b"8BIM" {
            return Err(TipImportError::Malformed("seção 8BIM"));
        }
        let tag = r.bytes(4)?;
        let size = r.u32()? as usize;
        if tag == b"samp" {
            break r
                .pos
                .checked_add(size)
                .ok_or(TipImportError::Malformed("tamanho"))?;
        }
        r.skip(size)?;
    };
    let section_end = section_end.min(r.data.len());
    let skip = if subversion == 1 { 47 } else { 301 };
    let mut import = TipImport::default();
    let mut index = 0;
    while r.pos + 4 <= section_end && import.tips.len() < MAX_TIPS_PER_FILE {
        let size = r.u32()? as usize;
        let padded = size.div_ceil(4) * 4;
        let next = r
            .pos
            .checked_add(padded)
            .ok_or(TipImportError::Malformed("tamanho"))?;
        if next > section_end + 4 || size == 0 {
            break;
        }
        let parsed = (|| {
            r.skip(skip)?;
            let (top, left, bottom, right) = (r.i32()?, r.i32()?, r.i32()?, r.i32()?);
            let depth = r.u16()?;
            let compressed = r.u8()? != 0;
            read_abr_bitmap(r, top, left, bottom, right, depth, compressed)
        })();
        index += 1;
        match parsed {
            Ok(tip) => import.tips.push(ImportedTip {
                name: format!("{stem} {index}"),
                tip,
                spacing: None,
            }),
            Err(error) => import
                .notes
                .push(format!("ponta {index} ignorada: {error}")),
        }
        r.seek(next.min(r.data.len()))?;
    }
    Ok(import)
}

fn read_ucs2(r: &mut Reader) -> Result<String, TipImportError> {
    let len = r.u32()? as usize;
    if len > 1024 {
        return Err(TipImportError::Malformed("nome longo demais"));
    }
    let mut units = Vec::with_capacity(len);
    for _ in 0..len {
        units.push(r.u16()?);
    }
    Ok(String::from_utf16_lossy(&units)
        .trim_end_matches('\0')
        .trim()
        .to_string())
}

/// Bitmap de uma ponta ABR: cru ou PackBits por linha, 8 ou 16 bits.
fn read_abr_bitmap(
    r: &mut Reader,
    top: i32,
    left: i32,
    bottom: i32,
    right: i32,
    depth: u16,
    compressed: bool,
) -> Result<TipImage, TipImportError> {
    let w = right
        .checked_sub(left)
        .filter(|v| *v > 0)
        .ok_or(TipImportError::Malformed("largura"))? as u32;
    let h = bottom
        .checked_sub(top)
        .filter(|v| *v > 0)
        .ok_or(TipImportError::Malformed("altura"))? as u32;
    let bytes_per_px = match depth {
        8 => 1,
        16 => 2,
        other => return Err(TipImportError::Unsupported(format!("ABR com {other} bits"))),
    };
    let total = checked_dims(w, h, bytes_per_px)?;
    let row = (w as usize) * bytes_per_px;
    let raw = if compressed {
        let mut lengths = Vec::with_capacity(h as usize);
        for _ in 0..h {
            lengths.push(r.u16()? as usize);
        }
        let mut out = Vec::with_capacity(total);
        for length in lengths {
            let line = r.bytes(length)?;
            let start = out.len();
            unpack_bits(line, &mut out, row)?;
            out.resize(start + row, 0);
        }
        out
    } else {
        r.bytes(total)?.to_vec()
    };
    let alpha = if bytes_per_px == 2 {
        raw.chunks_exact(2).map(|pair| pair[0]).collect()
    } else {
        raw
    };
    TipImage::new(w, h, alpha).ok_or(TipImportError::Malformed("dimensões"))
}

/// PackBits (TIFF/PSD): `n ≥ 0` copia `n + 1` bytes; `n < 0` repete o próximo
/// byte `1 − n` vezes; `−128` não faz nada. Para em `limit` bytes de saída.
fn unpack_bits(src: &[u8], out: &mut Vec<u8>, limit: usize) -> Result<(), TipImportError> {
    let start = out.len();
    let mut i = 0;
    while i < src.len() && out.len() - start < limit {
        let n = src[i] as i8;
        i += 1;
        if n >= 0 {
            let count = n as usize + 1;
            let chunk = src
                .get(i..i + count)
                .ok_or(TipImportError::Malformed("PackBits"))?;
            out.extend_from_slice(chunk);
            i += count;
        } else if n != -128 {
            let count = (1 - n as i32) as usize;
            let value = *src.get(i).ok_or(TipImportError::Malformed("PackBits"))?;
            out.extend(std::iter::repeat_n(value, count));
            i += 1;
        }
    }
    out.truncate(start + limit);
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    fn gbr(version: u32, w: u32, h: u32, bpp: u32, name: &str, pixels: &[u8]) -> Vec<u8> {
        let mut name_bytes = name.as_bytes().to_vec();
        name_bytes.push(0);
        let fixed = if version == 1 { 20 } else { 28 };
        let mut out = Vec::new();
        out.extend(((fixed + name_bytes.len()) as u32).to_be_bytes());
        out.extend(version.to_be_bytes());
        out.extend(w.to_be_bytes());
        out.extend(h.to_be_bytes());
        out.extend(bpp.to_be_bytes());
        if version != 1 {
            out.extend(b"GIMP");
            out.extend(25u32.to_be_bytes());
        }
        out.extend(name_bytes);
        out.extend(pixels);
        out
    }

    #[test]
    fn gbr_v2_grayscale_loads_name_spacing_and_pixels() {
        let bytes = gbr(2, 2, 2, 1, "Dot", &[0, 255, 255, 0]);
        let import = import_tips(&bytes, "x.gbr").unwrap();
        let tip = &import.tips[0];
        assert_eq!(tip.name, "Dot");
        assert_eq!(tip.spacing, Some(0.25));
        assert_eq!(tip.tip.alpha, vec![0, 255, 255, 0]);
    }

    #[test]
    fn gbr_v1_and_rgba_use_shape_only() {
        let v1 = gbr(1, 1, 1, 1, "Old", &[200]);
        assert_eq!(
            import_tips(&v1, "old.gbr").unwrap().tips[0].tip.alpha,
            vec![200]
        );
        let rgba = gbr(2, 1, 1, 4, "Color", &[10, 20, 30, 77]);
        let import = import_tips(&rgba, "c.gbr").unwrap();
        assert_eq!(import.tips[0].tip.alpha, vec![77]);
        assert!(!import.notes.is_empty(), "avisa que a cor foi ignorada");
    }

    #[test]
    fn abr_v2_sampled_with_packbits_decodes() {
        // Uma ponta 4×2, 8 bits, PackBits: linha 1 = 4×255, linha 2 = 0,255,255,0.
        let line1 = [(-3i8) as u8, 255];
        let line2 = [3u8, 0, 255, 255, 0];
        let mut body = Vec::new();
        body.extend(0u32.to_be_bytes()); // misc
        body.extend(30u16.to_be_bytes()); // spacing 30%
        let name: Vec<u16> = "Inky".encode_utf16().collect();
        body.extend((name.len() as u32).to_be_bytes());
        for unit in &name {
            body.extend(unit.to_be_bytes());
        }
        body.push(1); // antialias
        body.extend([0u8; 8]);
        for v in [0i32, 0, 2, 4] {
            body.extend(v.to_be_bytes()); // top, left, bottom, right
        }
        body.extend(8u16.to_be_bytes());
        body.push(1); // compressed
        body.extend((line1.len() as u16).to_be_bytes());
        body.extend((line2.len() as u16).to_be_bytes());
        body.extend(line1);
        body.extend(line2);
        let mut bytes = Vec::new();
        bytes.extend(2u16.to_be_bytes());
        bytes.extend(2u16.to_be_bytes()); // dois pincéis
        bytes.extend(1u16.to_be_bytes()); // computado (ignorado)
        bytes.extend(4u32.to_be_bytes());
        bytes.extend([0u8; 4]);
        bytes.extend(2u16.to_be_bytes()); // amostrado
        bytes.extend((body.len() as u32).to_be_bytes());
        bytes.extend(body);
        let import = import_tips(&bytes, "set.abr").unwrap();
        assert_eq!(import.tips.len(), 1);
        let tip = &import.tips[0];
        assert_eq!(tip.name, "Inky");
        assert_eq!(tip.spacing, Some(0.3));
        assert_eq!((tip.tip.w, tip.tip.h), (4, 2));
        // Borda clara (255): a polaridade é invertida.
        assert_eq!(tip.tip.alpha, vec![0, 0, 0, 0, 255, 0, 0, 255]);
        assert!(import.notes.iter().any(|n| n.contains("computado")));
    }

    #[test]
    fn abr_v6_reads_the_samp_section() {
        let mut brush = Vec::new();
        brush.extend([0u8; 301]);
        for v in [0i32, 0, 1, 2] {
            brush.extend(v.to_be_bytes());
        }
        brush.extend(8u16.to_be_bytes());
        brush.push(0);
        brush.extend([255u8, 0]);
        let mut samp = Vec::new();
        samp.extend((brush.len() as u32).to_be_bytes());
        let padded = brush.len().div_ceil(4) * 4;
        brush.resize(padded, 0);
        samp.extend(&brush);
        let mut bytes = Vec::new();
        bytes.extend(6u16.to_be_bytes());
        bytes.extend(2u16.to_be_bytes());
        bytes.extend(b"8BIM");
        bytes.extend(b"patt");
        bytes.extend(3u32.to_be_bytes());
        bytes.extend([1u8, 2, 3]);
        bytes.extend(b"8BIM");
        bytes.extend(b"samp");
        bytes.extend((samp.len() as u32).to_be_bytes());
        bytes.extend(samp);
        let import = import_tips(&bytes, "modern.abr").unwrap();
        assert_eq!(import.tips.len(), 1);
        assert_eq!((import.tips[0].tip.w, import.tips[0].tip.h), (2, 1));
        assert_eq!(import.tips[0].name, "modern 1");
    }

    #[test]
    fn png_tip_uses_darkness_when_opaque() {
        let mut png = Vec::new();
        let img = image::RgbaImage::from_raw(2, 1, vec![0, 0, 0, 255, 255, 255, 255, 255]).unwrap();
        image::DynamicImage::ImageRgba8(img)
            .write_to(&mut std::io::Cursor::new(&mut png), image::ImageFormat::Png)
            .unwrap();
        let import = import_tips(&png, "ink.png").unwrap();
        assert_eq!(import.tips[0].tip.alpha, vec![255, 0]);
        assert_eq!(import.tips[0].name, "ink");
    }

    #[test]
    fn svg_tip_rasterizes() {
        let svg = r#"<svg xmlns="http://www.w3.org/2000/svg" width="10" height="10"><circle cx="5" cy="5" r="4" fill="black"/></svg>"#;
        let import = import_tips(svg.as_bytes(), "dot.svg").unwrap();
        let tip = &import.tips[0].tip;
        assert!(tip.sample(0.0, 0.0) > 0.9, "centro cheio");
        assert!(tip.sample(0.98, 0.98) < 0.1, "canto vazio");
    }

    #[test]
    fn malformed_and_random_input_never_panics() {
        assert_eq!(
            import_tips(b"", "a.abr"),
            Err(TipImportError::Malformed("fim inesperado"))
        );
        assert_eq!(
            import_tips(b"hello", "a.txt"),
            Err(TipImportError::UnknownFormat)
        );
        let mut seed = 0x1234_5678u32;
        for len in 0..400 {
            let bytes: Vec<u8> = (0..len)
                .map(|_| {
                    seed ^= seed << 13;
                    seed ^= seed >> 17;
                    seed ^= seed << 5;
                    seed as u8
                })
                .collect();
            for name in ["x.abr", "x.gbr", "x.png", "x.svg"] {
                let _ = import_tips(&bytes, name);
            }
        }
        // Dimensões absurdas são recusadas antes de alocar.
        let huge = gbr(2, 100_000, 100_000, 1, "big", &[]);
        assert_eq!(import_tips(&huge, "big.gbr"), Err(TipImportError::TooLarge));
    }

    #[test]
    fn sample_is_centered_and_fit_reduces() {
        let tip = TipImage::new(3, 1, vec![0, 255, 0]).unwrap();
        assert!(tip.sample(0.0, 0.0) > 0.9);
        assert_eq!(tip.sample(0.0, 0.9), 0.0, "fora da faixa da imagem");
        let big = TipImage::new(512, 256, vec![255; 512 * 256])
            .unwrap()
            .fit(256);
        assert_eq!((big.w, big.h), (256, 128));
        assert!(big.alpha.iter().all(|&v| v == 255));
        assert_ne!(tip.content_hash(), 0);
    }
}
