//! Prévia de traço da biblioteca de pincéis (ADR 008).
//!
//! A prévia é desenhada pelo próprio motor de pintura: uma curva em S num
//! estado de pintura isolado, com o preset aplicado. Assim o que se vê na
//! biblioteca é o que o pincel faz, inclusive ponta por imagem, jitter e
//! dispersão.

use petunia_core::{AppState, BrushPreset, BrushType};
use petunia_project::Canvas;

use crate::PaintModule;

/// Gera prévias reaproveitando um único estado de pintura.
pub struct BrushPreviewRenderer {
    state: AppState,
    w: u32,
    h: u32,
}

impl BrushPreviewRenderer {
    /// Renderizador para prévias de `w × h` texels.
    pub fn new(w: u32, h: u32) -> Self {
        let (w, h) = (w.max(16), h.max(8));
        let mut state = AppState::default();
        PaintModule::ensure_canvas(&mut state);
        PaintModule::ensure_stack(&mut state);
        PaintModule::resize_canvas(&mut state, w, h);
        Self { state, w, h }
    }

    /// Prévia RGBA: tinta branca sobre transparente (pincéis de pintura) ou
    /// sobre listras (pincéis que só mexem no que já existe).
    pub fn render(&mut self, preset: &BrushPreset) -> Canvas {
        let (w, h) = (self.w, self.h);
        let state = &mut self.state;
        let effect = matches!(
            preset.settings.kind,
            BrushType::Smudge
                | BrushType::Blur
                | BrushType::Dodge
                | BrushType::Burn
                | BrushType::Clone
        );
        let background = if effect {
            stripes(w, h)
        } else {
            Canvas::new(w, h, [0, 0, 0, 0])
        };
        let active = state.project.active;
        if let Some(layer) = state
            .project
            .assets
            .get_mut(active)
            .and_then(|asset| asset.paint_stack.as_mut())
            .and_then(|stack| stack.active_mut())
            && let Some(canvas) = layer.canvas_mut()
        {
            *canvas = background;
        }
        state.paint_color = [1.0, 1.0, 1.0];
        state.session.tools.paint_color = [1.0, 1.0, 1.0];
        let mut style = preset.style;
        if let Some(tip) = &preset.tip {
            style.tip_image = state.session.tools.brush_tips.register(tip);
        }
        state.session.tools.brush_style = style;
        state.session.tools.clone_source = Some([w as f32 * 0.5, 2.0]);
        let mut settings = preset.settings.sanitized();
        // Cabe na altura da prévia sem perder a proporção entre pincéis.
        settings.size_px = settings.size_px.clamp(2.0, h as f32 * 0.55);
        let points = s_curve(w, h, settings.size_px, settings.spacing);
        state.session.tools.paint_buffer = None;
        PaintModule::stamp_dabs_2d(state, &points, settings);
        state.session.tools.paint_buffer = None;
        state
            .project
            .assets
            .get(state.project.active)
            .and_then(|asset| asset.paint_stack.as_ref())
            .and_then(|stack| stack.active())
            .and_then(|layer| layer.canvas())
            .cloned()
            .unwrap_or_else(|| Canvas::new(w, h, [0, 0, 0, 0]))
    }
}

/// Pontos de uma curva em S, espaçados pelo `spacing` do pincel.
fn s_curve(w: u32, h: u32, size: f32, spacing: f32) -> Vec<(u32, u32)> {
    let margin = size * 0.5 + 2.0;
    let step = (size * spacing.clamp(0.01, 1.0)).max(1.0);
    let span = (w as f32 - margin * 2.0).max(1.0);
    let amplitude = ((h as f32 - margin * 2.0) * 0.5).max(0.0);
    let mid = h as f32 * 0.5;
    let mut points = Vec::new();
    let mut last: Option<(f32, f32)> = None;
    let samples = (span * 4.0) as u32;
    for i in 0..=samples {
        let t = i as f32 / samples.max(1) as f32;
        let x = margin + span * t;
        let y = mid - amplitude * (t * std::f32::consts::TAU).sin();
        let far_enough =
            last.is_none_or(|(lx, ly)| ((x - lx).powi(2) + (y - ly).powi(2)).sqrt() >= step);
        if far_enough {
            points.push((
                x.round() as u32,
                y.round().clamp(0.0, h as f32 - 1.0) as u32,
            ));
            last = Some((x, y));
        }
    }
    points
}

/// Listras cinza/claro, base visível para borrar, desfocar e clarear.
fn stripes(w: u32, h: u32) -> Canvas {
    let mut canvas = Canvas::new(w, h, [0, 0, 0, 0]);
    for y in 0..h {
        for x in 0..w {
            let band = (x / 6) % 2 == 0;
            let value = if band { 190 } else { 90 };
            canvas.set(x, y, [value, value, value, 255]);
        }
    }
    canvas
}

#[cfg(test)]
mod tests {
    use super::*;

    fn painted(canvas: &Canvas) -> usize {
        canvas.pixels.chunks_exact(4).filter(|px| px[3] > 0).count()
    }

    #[test]
    fn every_builtin_brush_draws_something() {
        let mut renderer = BrushPreviewRenderer::new(160, 48);
        for preset in BrushPreset::builtin() {
            let canvas = renderer.render(&preset);
            assert_eq!((canvas.w, canvas.h), (160, 48));
            assert!(painted(&canvas) > 40, "{} não desenhou", preset.name);
        }
    }

    #[test]
    fn image_tip_changes_the_stroke() {
        let mut renderer = BrushPreviewRenderer::new(160, 48);
        let presets = BrushPreset::builtin();
        let hard = presets.iter().find(|p| p.name == "Hard round").unwrap();
        let sponge = presets.iter().find(|p| p.name == "Sponge").unwrap();
        let a = renderer.render(hard);
        let b = renderer.render(sponge);
        assert_ne!(a, b);
        // A esponja tem buracos: menos texels cheios que o pincel redondo.
        let full = |c: &Canvas| c.pixels.chunks_exact(4).filter(|px| px[3] > 250).count();
        assert!(full(&b) < full(&a));
    }
}
