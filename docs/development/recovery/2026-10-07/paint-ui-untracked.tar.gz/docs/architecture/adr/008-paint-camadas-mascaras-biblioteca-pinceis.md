# ADR 008 — PAINT: camadas com máscara, efeitos com escopo e biblioteca de pincéis

Status: aceito em 2026-10-05 por autorização explícita do responsável do produto
("prossiga com essa implementação completa").
Autoridade: [P3D-061](../../bible/specs/p3d-061-simple-paint-layers.md) (camadas),
[P3D-132](../../bible/specs/p3d-132-paint-masks-face-selection-isolation.md)
(máscaras), [P3D-134](../../bible/specs/p3d-134-paint-effect-stack.md) (efeitos)
e [capítulo 44](../../bible/foundations/44-pos-v1-surface-paint-toolbox.md).
Este ADR registra o motivo; não cria uma segunda baseline.

## Contexto

O responsável avaliou o Inspector do PAINT como poluído e pediu camadas
"próximas do Affinity, Photoshop e Substance, mas fáceis de entender":

- efeitos eram uma seção à parte, com botões soltos, embora o modelo já os
  tratasse como camadas aplicadas a tudo o que está abaixo (P3D-134);
- não havia como um efeito afetar só uma camada, nem máscaras não destrutivas;
- grupos existiam no arquivo, mas a composição os ignorava;
- os pincéis eram uma grade de nomes, sem prévia do traço, e só aceitavam
  pontas geométricas;
- os valores do pincel usavam botões − e + grandes, sem digitar nem arrastar.

Referências estudadas: Affinity (ajustes e filtros ao vivo como camadas;
aninhar limita o efeito; toda camada de ajuste tem máscara), Photoshop
(clipping; bibliotecas ABR), Substance Painter (máscaras em toda camada), e as
bibliotecas de pincel do Blender, do Affinity e do Procreate (prévia de traço).

## Decisão

1. **Efeito é camada, com escopo explícito.** O botão ◐ da pilha insere o
   efeito acima da camada ativa (P3D-134). Cada efeito escolhe **"Afeta: tudo
   abaixo"** (padrão, comportamento atual) ou **"só a camada abaixo"**
   (`clip_to_below`): o efeito modifica o conteúdo da camada irmã logo abaixo
   antes de ela ser misturada. Um seletor no lugar de gesto escondido (o
   aninhamento por arrasto do Affinity) mantém o "fácil de entender" do P3D-061.
2. **Grupos isolados.** A composição passa a ser hierárquica: os filhos de um
   grupo são compostos num buffer próprio e o resultado é misturado com a
   opacidade, o modo e a máscara do grupo. Efeito dentro de grupo afeta só o
   grupo.
3. **Máscara de camada não destrutiva** (P3D-132, "layer mask quando a
   arquitetura justificar"): qualquer camada (pintura, decalque, efeito, grupo)
   pode ter uma máscara em tons de cinza no tamanho da textura; branco mostra,
   preto esconde (valor = luminância × alfa). Pintar na máscara usa o mesmo
   motor de traço, com a cor convertida em cinza. A máscara entra no arquivo
   como campo opcional; arquivos antigos abrem iguais.
4. **Biblioteca de pincéis.** Pincéis são apresentados por uma prévia de traço
   desenhada pelo próprio motor, em categorias, com busca, editor de parâmetros
   com prévia ao vivo e menu de contexto (editar, duplicar, redefinir, excluir).
5. **Ponta por imagem.** `BrushTip::Image` amostra uma imagem em tons de cinza
   (bilinear, girada e achatada como as pontas geométricas). As pontas vivem na
   biblioteca do usuário, não no projeto: o que vai para o projeto são pixels.
6. **Importação de pontas**, com leitura defensiva (limites de tamanho, sem
   pânico com arquivo malformado): PNG/JPEG, SVG (rasterizado pelo mesmo
   caminho dos decalques), GBR do GIMP e ABR do Photoshop (versões 1, 2 e 6+,
   pontas amostradas). Da dinâmica do ABR só entra o que existe no pincel do
   Petunia (espaçamento); o resto é ignorado e informado.
7. **Valores digitáveis e arrastáveis** em todo o PAINT, no lugar de − e +.

## Consequências

- O formato de camada ganha `mask`, `mask_enabled` e `clip_to_below`, todos
  opcionais (`serde(default)`), sem quebrar arquivos existentes.
- `composite` e `composite_tiles` passam a usar o mesmo algoritmo por região, o
  que mantém a equivalência testada entre composição completa e por tiles.
- Fora deste ADR: camadas com vários canais PBR (estilo Substance), modos de
  mistura além dos quatro atuais, efeitos de camada (sombra, contorno) e
  dinâmica completa do ABR.
